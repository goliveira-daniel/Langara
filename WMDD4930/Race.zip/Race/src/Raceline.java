public class Raceline {
	private int lenght;
	public boolean isRaceOver = false;
	
	public Raceline (int lenght) {
		this.setLenght(lenght);
	}
	
	public String drawnRaceLine (int harePosition, int turtoisePosition) {
		String raceLine = "";
		String thisPosition = "";
		
		for (int i = 1; i <= this.getLenght(); i++) {
			thisPosition = ".";
			if (i == 1) {thisPosition = "S";}
			if (i == this.getLenght()) {
				if (harePosition >= raceLine.length()) {
					thisPosition = "H";
				} else if (isRaceOver) {
					thisPosition = "T";
				} else {
					thisPosition = "F";
				}
			}
			if (i == harePosition) {thisPosition = "H";}
			if (i == turtoisePosition) {thisPosition = "T";}
			if (i == harePosition && i == turtoisePosition) {thisPosition = "B";}
			raceLine += thisPosition;
		}
		
		if (harePosition >= raceLine.length() || turtoisePosition >= raceLine.length()) {
			isRaceOver = true;
		}
		
		return raceLine;
	}
	
//	public void printRaceLine () {
//		System.out.println(createRaceLine(harePosition, turtoisePosition));
//	}

	public int getLenght() {
		return lenght;
	}

	public void setLenght(int lenght) {
		this.lenght = lenght;
	}
}