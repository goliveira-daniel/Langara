/**
 * 
 */

/**
 * @author Avell B155 FIRE
 *
 */
public class Turtoise extends Animal {

	@Override
	int move() {
		// TODO Auto-generated method stub
		switch (moveType()) {
		case 1:
		case 2:
		case 3:
		case 4:
		case 5:
			return 3;
		case 6:
		case 7:
			return -6;
		case 8:
		case 9:
		case 10:
			return 1;
		default:
			return 0;
		}
	}
	
}
