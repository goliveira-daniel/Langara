/**
 * 
 */

/**
 * @author Daniel Oliveira
 *
 */
public class Hare extends Animal {
	@Override
	int move() {
		// TODO Auto-generated method stub
		switch (moveType()) {
		case 1:
		case 2:
			return 0;
		case 3:
		case 4:
			return 9;
		case 5:
			return -12;
		case 6:
		case 7:
		case 8:
			return 1;
		case 9:
		case 10:
			return -2;
		default:
			return 0;
		}
	}
}
