
public class RaceTest {
	public static void main( String[] args ) {
		Raceline raceline = new Raceline(70);
		Turtoise turtoise = new Turtoise();
		Hare hare =  new Hare();
		
		System.out.println("Competitors are at the start line...");
		System.out.println("...AAAAAND BANG!!! THE RACE STARTS!!!!");
		int i = 1;
		do {
			turtoise.setPosition(turtoise.move());
			hare.setPosition(hare.move());
			System.out.println("ROUND " + i + ": " + raceline.drawnRaceLine(hare.getPosition(), turtoise.getPosition()));
			i++;
		} while (!raceline.isRaceOver);
		
		if (turtoise.getPosition() >= raceline.getLenght()) {
			System.out.println("THE TURTOISE WINSSSSS THE RACE!!!");			
		} else {
			System.out.println("And the hare is the champion of this race.");
		}
	}
}
