import java.util.Random;

public abstract class Animal {
	private int position = 1;
	
	abstract int move();
	
	public int moveType(){
		Random rand = new Random(); 
		return rand.nextInt(10) + 1;
	}

	public int getPosition() {
		return position;
	}

	public void setPosition(int positionsMoved) {
		if (position + positionsMoved < 1) {
			this.position = 1;
		} else {
			this.position = position + positionsMoved;
		}
	}
}
