// Fig. 7.9: Card.java
// Card class represents a playing card.

import java.util.Comparator;

public class Card 
{
   private final String face; // face of card ("Ace", "Deuce", ...)
   private final String suit; // suit of card ("Hearts", "Diamonds", ...)
   
   
   public String getFace() {
	return face;
}

	public String getSuit() {
		return suit;
	}

   // two-argument constructor initializes card's face and suit
   public Card(String face, String suit)
   {
      this.face = face;
      this.suit = suit; 
   } 


   // return String representation of Card
   @Override
   public String toString() 
   { 
      return face + " of " + suit;
   }
   
   public static Comparator<Card> CardFaceComparator = new Comparator<Card>() {

		public int compare(Card card1, Card card2) {
		
		String cardFace1 = card1.getFace().toUpperCase();
		String cardFace2 = card2.getFace().toUpperCase();
		
		//ascending order
		return cardFace1.compareTo(cardFace2);
		
		//descending order
		//return fruitName2.compareTo(fruitName1);
		}
   };
} // end class Card

