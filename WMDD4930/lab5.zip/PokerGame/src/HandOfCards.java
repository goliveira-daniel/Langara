import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class HandOfCards {
	private Card[] handOfCards;
	private int cardsOnHand = 0;
    private static final int NUMBER_OF_CARDS = 5;
    private List <Game> Games = new ArrayList <Game>();
    private int handValue = 0;
	
	public HandOfCards(Card[] cards) {
		handOfCards = new Card[cards.length];		
	}
	
	public HandOfCards() {
		handOfCards = new Card[NUMBER_OF_CARDS];		
	}
	
	public Card[] getHandOfCards() {
		return handOfCards;
	}


	public String getGames() {
		String str = "No relevant games";
		
		if (Games != null) {
//			str = "";
			for (Game game : Games) {
				str += game.getGameName() + " ";
			}
		} 
		
		return str;
	}
//
//	public void addGames(List<Game> games) {
//		this.Games = games;
//	}

	public int getHandValue() {
		setHandValue();
		return handValue;
	}

	private void setHandValue() {
		if (Games != null) {
			for (Game game : Games) {
				this.handValue += game.getGameValue();
			}
		}
	}

	public void addCard(Card card) {
		if (cardsOnHand < handOfCards.length) {
			handOfCards[cardsOnHand] = card;
			cardsOnHand++;
		}
	}
	
	public void checkHand() {
		Arrays.sort(handOfCards, Card.CardFaceComparator);

		int dups = 0;
		boolean flush = true;

		for (int i = 0; i < handOfCards.length; i++) { 
			for (int j = i + 1 ; j < handOfCards.length; j++) {
				if (handOfCards[i].getFace().equals(handOfCards[j].getFace())) {
					dups++;
					// get the duplicate element
				}
//				if flush is true but the cards does not the same suit, then negate flush
				if (flush && !handOfCards[i].getSuit().equals(handOfCards[j].getSuit())) {
					flush = false;
				}
			}
			
			switch (dups) {
			case 1: Games.add(new Game ("A pair")); dups = 0; break;
			case 2: Games.add(new Game ("Three of a kind")); dups = 0; break;
			case 3: Games.add(new Game ("Four of a kind")); dups = 0; break;
			case 0: 
			default: break;
			}				
		}
		
		if (flush) {
			Games.add(new Game ("flush"));
		}
		
	}
}
