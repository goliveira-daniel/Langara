// Fig. 7.11: DeckOfCardsTest.java
// Card shuffling and dealing.

public class DeckOfCardsTest
{
   // execute application
   public static void main(String[] args)
   {
      DeckOfCards myDeckOfCards = new DeckOfCards();
      myDeckOfCards.shuffle(); // place Cards in random order
      
      // print all 52 Cards in the order in which they are dealt
//      for (int i = 1; i <= 52; i++)
//      {
//         // deal and display a Card
//         System.out.printf("%-19s", myDeckOfCards.dealCard());
//
//		 if (i % 4 == 0) // output a newline after every fourth card
//		    System.out.println();
//      }
      
      HandOfCards myHand = new HandOfCards();
      HandOfCards otherHand = new HandOfCards();
      
      for (int i = 0; i < 5; i++) {
    	  myHand.addCard(myDeckOfCards.dealCard());
      }
      
      for (int i = 0; i < 5; i++) {
    	  otherHand.addCard(myDeckOfCards.dealCard());
      }
      
      System.out.println("Cards of the first hand: ");
      
      for ( Card card : myHand.getHandOfCards()) {
		System.out.println(card);
      }
      
      System.out.println();
      System.out.println("Hand 1 contains:");
      myHand.checkHand();
      System.out.println(myHand.getGames());
      
      System.out.println("");
      
      System.out.println("Cards of the second hand: ");
      
      for ( Card card : myHand.getHandOfCards()) {
		System.out.println(card);
      }
      
      System.out.println();
      System.out.println("Hand 2 contains:");
      otherHand.checkHand();
      System.out.println(otherHand.getGames());
   
	   System.out.println("");
	   
	   if (myHand.getHandValue() > otherHand.getHandValue()) {
		      System.out.println("Hand 1 is the winner");
	   } else if (otherHand.getHandValue() > myHand.getHandValue()) {
		      System.out.println("Hand 2 is the winner");
	   } else {
		      System.out.println("It's a tie");
	   }   
   }
} // end class DeckOfCardsTest

