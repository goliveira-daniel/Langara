//import java.util.ArrayList;
//import java.util.List;

public class Game{
	private final String gameName;
//	private List <Card> cards;
	private int gameValue; 
	
	public Game(String game) {
		this.gameName = game;
//		this.cards = new ArrayList<Card>(cards);
		this.setGameValue();
	}
	
	public String getGameName() {
		return gameName;
	}

	public int getGameValue() {
		return gameValue;
	}

	private void setGameValue() {
		switch (gameName.toLowerCase()) {
		case "a pair":
			this.gameValue = 200;
			break;
		case "three of a kind":
			this.gameValue = 300;
			break;
		case "four of a kind":
			this.gameValue = 400;
			break;			
		case "flush":
			this.gameValue = 500;
			break;
		case "straight":
			this.gameValue = 500;
			break;
		case "full house":
			this.gameValue = 600;
			break;
		default:
			break;
		};
	}
	
}
