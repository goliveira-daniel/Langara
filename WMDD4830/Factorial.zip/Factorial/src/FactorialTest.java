import java.util.Scanner;

public class FactorialTest {
	   public static void main(String[] args) 
	   {
	      // create a Scanner to obtain input from the command window
	      Scanner input = new Scanner(System.in);

	      System.out.print("Enter an integer to calculate its fatorial: "); // prompt
	      Factorial factorial = new Factorial(input.nextInt());
	      System.out.println(factorial.printFatorial());
	      input.close();
	   }
}