import java.util.Random;
import java.util.Scanner;

public class Guess {
	public static void main( String[] args ) {
		Scanner input = new Scanner(System.in);

		Random rand = new Random(); 
		int value = rand.nextInt(1000) + 1; 		

		System.out.print("Guess a number between 1 and 1000: ");
//		Factorial factorial = new Factorial(input.nextInt());
		int guessed = input.nextInt();
		while (guessed != value) {
			if (guessed < value) {
				System.out.print("Too low. Try again: ");
			} else {
				System.out.print("Too high. Try again: ");
			}
			guessed = input.nextInt();
		}
		System.out.print("Congratulations, you guessed the number!");
		input.close();
	}
}
