import java.util.Scanner;
//import java.util.Arrays;
//import java.util.Random;

public class PlaneTest {
	public static void main( String[] args ) {
		Scanner input = new Scanner(System.in);
		Plane plane = new Plane();
		
		while (plane.hasSeats) {
			System.out.print("Please type 1 for first class or type 2 for economy: ");
	
			int userInput = input.nextInt();
	//		Arrays.equals(arg0, arg1)
	//		seats.
				
			switch (userInput) {
			case 1:
				if (plane.getFirstClass()) {
					System.out.println("Ticket reserved!");
				} else {
					System.out.println("There's no seats available on first class!");
				};
				break;
			case 2:
				if (plane.getEconomy()) {
					System.out.println("Ticket reserved!");
				} else {
					System.out.println("There's no seats available on economy class!");
				};
				break;
			default:
				System.out.print("Invalid option. Please type 1 for first class or type 2 for economy: ");
				break;
			}
		}
		System.out.print("This flight is all booked. Next one leaves in 3 hours.");
		input.close();
	}
}