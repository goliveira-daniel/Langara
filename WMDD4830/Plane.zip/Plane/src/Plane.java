
public class Plane {
	private final int totalSeats = 10;
	private boolean[] seats = new boolean[totalSeats];
	public boolean hasSeats = true;
	private int ticketsAvailable = 10;
	
	public Plane () {
		
	}
	
	public boolean getFirstClass() {
		if (!hasSeats) return false;
		for (int i = 0; i <= 4; i++) {
			if (!seats[i]) {
				seats[i] = true;
				reserveTicket();
				return true;
			};
		}
		return false;
	}
	
	public boolean getEconomy() {
		if (!hasSeats) return false;
		for (int i = 5; i <= 9; i++) {
			if (!seats[i]) {
				seats[i] = true;
				reserveTicket();
				return true;
			};
		}
		return false;
	}
	
	private void reserveTicket() {
		ticketsAvailable--;
		if (ticketsAvailable == 0) {
			hasSeats = false;
		}
	}
}