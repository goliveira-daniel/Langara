import java.util.Scanner;

public class ExTest {
	 public static void main(String[] args) 
	   {
	      // create a Scanner to obtain input from the command window
	      Scanner input = new Scanner(System.in);

	      System.out.print("Enter an integer to calculate e: "); // prompt
	      E e = new E(input.nextInt());
	      System.out.println(e.printE());
	      input.close();
	   }
}
