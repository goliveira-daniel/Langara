import java.util.Random;
import java.util.Scanner;

public class Guess2 {
	public static void main( String[] args ) {
		Scanner input = new Scanner(System.in);

		Random rand = new Random(); 
		int value = rand.nextInt(1000) + 1;
		int tries = 0;

		System.out.print("Guess a number between 1 and 1000: ");
//		Factorial factorial = new Factorial(input.nextInt());
		int guessed = input.nextInt();
		while (guessed != value) {
			if (guessed < value) {
				System.out.print("Too low. Try again: ");
			} else {
				System.out.print("Too high. Try again: ");
			}
			tries++;
			guessed = input.nextInt();
		}
		if (tries < 10) {
			System.out.print("Either you know the secret or you got lucky!");			
		} else if (tries == 10) {
			System.out.print("Aha! You know the secret!");						
		} else {
			System.out.print("You should be able to do better!");			
		}
		input.close();
	}
}
