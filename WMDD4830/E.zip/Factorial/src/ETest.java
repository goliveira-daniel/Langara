import java.util.Scanner;

public class ETest {
	 public static void main(String[] args) 
	   {
	      // create a Scanner to obtain input from the command window
	      Scanner input = new Scanner(System.in);

	      System.out.print("Enter an integer to calculate e (x): "); // prompt
	      Ex ex = new Ex(input.nextInt());
	      System.out.println(ex.printEx());
	      input.close();
	   }
}
